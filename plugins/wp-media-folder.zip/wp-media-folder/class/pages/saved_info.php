<?php
/* Prohibit direct script loading */
defined('ABSPATH') || die('No direct script access allowed!');
?>
<div class='success updated'>
    <p><?php _e('Saved successfully', 'wpmf'); ?></p>
</div>
