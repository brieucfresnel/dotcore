<?php
/* Prohibit direct script loading */
defined('ABSPATH') || die('No direct script access allowed!');
?>
<div class="btn_wpmf_saves">
    <input type="submit" name="btn_wpmf_save"
           id="btn_wpmf_save" class="btn_wpmf_save btn waves-effect waves-light waves-input-wrapper"
           value="<?php _e('Save Changes', 'wpmf'); ?>">
</div>