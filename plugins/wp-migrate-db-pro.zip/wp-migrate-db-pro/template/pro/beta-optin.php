<tr>
	<td>
		<?php $this->template( 'checkbox', 'common', array( 'key' => 'beta_optin' ) ); ?>
	</td>
	<td>
		<h4><?php _e( 'Beta Version Updates', 'wp-migrate-db' ); ?><span class="setting-status"></span></h4>
		<p><?php _e( 'When a beta version of WP Migrate DB Pro is available, show a WordPress update notice and allow updating to the beta like any other plugin update.', 'wp-migrate-db' ); ?></p>
	</td>
</tr>
